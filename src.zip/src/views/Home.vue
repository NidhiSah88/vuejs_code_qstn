<template>
  <div class="home">
    <h1>
      HOME The Model—View—Controller(MVC) Pattern The MVC pattern suggests
      splitting the code into 3 components. While creating the class/file of the
      application, the developer must categorize it into one of the following
      three layers: Model: This component stores the application data. It has no
      knowledge about the interface. The model is responsible for handling the
      domain logic(real-world business rules) and communication with the
      database and network layers. View: It is the UI(User Interface) layer that
      holds components that are visible on the screen. Moreover, it provides the
      visualization of the data stored in the Model and offers interaction to
      the user. Controller: This component establishes the relationship between
      the View and the Model. It contains the core application logic and gets
      informed of the user’s response and updates the Model as per the need. The
      Model—View—Controller(MVC) Pattern The Model — View — ViewModel (MVVM)
      Pattern MVVM pattern has some similarities with the MVP(Model — View —
      Presenter) design pattern as the Presenter role is played by the
      ViewModel. However, the drawbacks of the MVP pattern has been solved by
      MVVM. It suggests separating the data presentation logic(Views or UI) from
      the core business logic part of the application. The separate code layers
      of MVVM are: Model: This layer is responsible for the abstraction of the
      data sources. Model and ViewModel work together to get and save the data.
      View: The purpose of this layer is to inform the ViewModel about the
      user’s action. This layer observes the ViewModel and does not contain any
      kind of application logic. ViewModel: It exposes those data streams which
      are relevant to the View. Moreover, it servers as a link between the Model
      and the View. An SPA (Single-page application) is a web app implementation
      that loads only a single web document, and then updates the body content
      of that single document via JavaScript APIs such as XMLHttpRequest and
      Fetch when different content is to be shown. What is the difference
      between one-way data flow/ or one-way data binding and two-way data
      binding? In one-way data binding or one-way data flow, the view (UI) part
      of the application does not update automatically. In this model, when the
      data Model is changed, you need to write some custom code to make it
      updated every time after the change. The v-bind directive is used for
      one-way data flow or binding in Vue.js. On the other hand, in two-way data
      binding, the view (UI) part of the application is automatically updated
      when the data Model is changed. The v-model directive is used for two way
      data binding in Vue.js.
    </h1>
  </div>
</template>
